﻿namespace Cadastro_Venda_Veiculos.Models
{
    public abstract class PadraoViewModel
    {
        public virtual int Id { get; set; }
    }
}


﻿namespace Cadastro_Venda_Veiculos.Models
{
    public class CidadeViewModel : PadraoViewModel
    {
        public string Nome { get; set; }
    }
}

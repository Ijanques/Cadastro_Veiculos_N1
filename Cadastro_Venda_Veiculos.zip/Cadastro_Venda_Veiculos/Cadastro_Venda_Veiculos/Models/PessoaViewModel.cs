﻿namespace Cadastro_Venda_Veiculos.Models
{
    public class PessoaViewModel
    {
        public int ID { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
        public string Tipo { get; set; }
    }

}

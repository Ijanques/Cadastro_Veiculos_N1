﻿using Cadastro_Venda_Veiculos.DAO;
using Cadastro_Venda_Veiculos.Models;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace Cadastro_Venda_Veiculos.Controllers
{
    public class PessoaController : Controller
    {
        private PessoaDAO pessoaDAO = new PessoaDAO();

        public IActionResult Index()
        {
            List<PessoaViewModel> lista = pessoaDAO.Listagem();
            return View(lista);
        }

        public IActionResult Create()
        {
            ViewBag.Operacao = "I";
            try
            {
                PessoaViewModel pessoa = new PessoaViewModel();
                pessoa.ID = pessoaDAO.ProximoId(); // Supondo que você tem um método para obter o próximo ID
                return View("Form", pessoa);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel { Erro = erro.ToString() });
            }
        }

        public IActionResult Salvar(PessoaViewModel pessoa, string Operacao)
        {
            try
            {
                ValidaDados(pessoa, Operacao);
                if (!ModelState.IsValid)
                {
                    ViewBag.Operacao = Operacao;
                    return View("Form", pessoa);
                }
                else
                {
                    if (Operacao == "I")
                    {
                        if (pessoaDAO.Consulta(pessoa.ID) == null)
                            pessoaDAO.Inserir(pessoa);
                        else
                            pessoaDAO.Alterar(pessoa);
                    }
                    else
                    {
                        pessoaDAO.Alterar(pessoa);
                    }
                    return RedirectToAction("Index");
                }
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel { Erro = erro.ToString() });
            }
        }



        public IActionResult Edit(int id)
        {
            try
            {
                ViewBag.Operacao = "A";

                PessoaViewModel pessoa = pessoaDAO.Consulta(id);
                if (pessoa == null)
                    return RedirectToAction("Index");
                else
                    return View("Form", pessoa);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel { Erro = erro.ToString() });
            }
        }


        public IActionResult Delete(int id)
        {
            try
            {
                pessoaDAO.Excluir(id);
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel { Erro = erro.ToString() });
            }
        }

        private void ValidaDados(PessoaViewModel pessoa, string operacao)
        {
            ModelState.Clear(); // limpa os erros criados automaticamente pelo Asp.net (que podem estar com msg em inglês)
            if (operacao == "I" && pessoaDAO.Consulta(pessoa.ID) != null)
                ModelState.AddModelError("ID", "Código já está em uso.");
            if (operacao == "A" && pessoaDAO.Consulta(pessoa.ID) == null)
                ModelState.AddModelError("ID", "Pessoa não existe.");
            if (pessoa.ID <= 0)
                ModelState.AddModelError("ID", "Id inválido!");

            if (string.IsNullOrEmpty(pessoa.Nome))
                ModelState.AddModelError("Nome", "Preencha o nome.");
            if (string.IsNullOrEmpty(pessoa.Telefone))
                ModelState.AddModelError("Telefone", "Campo obrigatório.");
            if (string.IsNullOrEmpty(pessoa.Tipo) || (pessoa.Tipo != "Comprador" && pessoa.Tipo != "Vendedor"))
                ModelState.AddModelError("Tipo", "Selecione um tipo válido.");
        }
    }
}

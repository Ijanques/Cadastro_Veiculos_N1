﻿using Cadastro_Venda_Veiculos.Models;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System;

namespace Cadastro_Venda_Veiculos.DAO
{
    public class PessoaDAO
    {
        public void Inserir(PessoaViewModel pessoa)
        {
            HelperDAO.ExecutaProc("SpInserePessoa", CriaParametros(pessoa));
        }

        public void Alterar(PessoaViewModel pessoa)
        {
            HelperDAO.ExecutaProc("SpAlteraPessoa", CriaParametros(pessoa));
        }

        private SqlParameter[] CriaParametros(PessoaViewModel pessoa)
        {
            SqlParameter[] parametros = new SqlParameter[4];
            parametros[0] = new SqlParameter("Id", pessoa.ID);
            parametros[1] = new SqlParameter("Nome", pessoa.Nome);
            parametros[2] = new SqlParameter("Telefone", pessoa.Telefone);
            parametros[3] = new SqlParameter("Tipo", pessoa.Tipo);

            return parametros;
        }

        public void Excluir(int Id)
        {
            var p = new SqlParameter[]
            {
            new SqlParameter("Id", Id)
            };
            HelperDAO.ExecutaProc("SpExcluiPessoa", p);
        }

        private PessoaViewModel MontaPessoa(DataRow registro)
        {
            PessoaViewModel pessoa = new PessoaViewModel();
            pessoa.ID = Convert.ToInt32(registro["Id"]);
            pessoa.Nome = registro["Nome"].ToString();
            pessoa.Telefone = registro["Telefone"].ToString();
            pessoa.Tipo = registro["Tipo"].ToString();

            return pessoa;
        }

        public PessoaViewModel Consulta(int Id)
        {
            var p = new SqlParameter[]
            {
            new SqlParameter("Id", Id)
            };
            DataTable tabela = HelperDAO.ExecutaProcSelect("SPConsultaPessoa", p);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return MontaPessoa(tabela.Rows[0]);
        }

        public List<PessoaViewModel> Listagem()
        {
            List<PessoaViewModel> lista = new List<PessoaViewModel>();

            DataTable tabela = HelperDAO.ExecutaProcSelect("SpListagemPessoa", null);
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaPessoa(registro));
            return lista;
        }
        public int ProximoId()
        {
            var p = new SqlParameter[]
            {
                new SqlParameter("tabela", "pessoa")
            };
            DataTable tabela = HelperDAO.ExecutaProcSelect("spProximoId", p);
            return Convert.ToInt32(tabela.Rows[0]["MAIOR"]);
        }
    }
}
